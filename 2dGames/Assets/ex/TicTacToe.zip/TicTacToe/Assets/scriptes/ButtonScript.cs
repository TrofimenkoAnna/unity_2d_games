﻿using UnityEngine;

public class ButtonScript : MonoBehaviour
{

    public void RestartButton_OnClick()
    {
        GameObject.Find("GamePlay").GetComponent<GamePlayController>().Restart();
        GetComponent<AudioSource>().Play();
    }
}
