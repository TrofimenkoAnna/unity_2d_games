﻿using UnityEngine;
using System.Collections;

public static class Turn
{
    public static bool turn = false;
    static bool pause = false;

    public static bool Pause
    {
        get { return pause; }
    }

    public static IEnumerator SetPouse()
    {
        pause = true;
        yield return new WaitForSeconds(0.6f);
        pause = false;
    }
}
