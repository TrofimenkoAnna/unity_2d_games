﻿using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    bool enable = true;
    public Sprite round;
    public string namePlayer = "Round";
    private List<Transform> freeCells;      //Коллекция свободных ячеек

    // Use this for initialization
    void Start ()
    {
        InitArrayCells();
    }
    // Update is called once per frame
    void Update()
    {
        if (enable && Turn.turn && !Turn.Pause)
            TurnEnemy();
    }

    /// <summary>
    /// Инициализируем коллекцию свободных ячеек
    /// </summary>
    void InitArrayCells()
    {
        freeCells = new List<Transform>();
        GameObject[] tempArr = GameObject.FindGameObjectsWithTag("cell");

        foreach (GameObject obj in tempArr)
            freeCells.Add(obj.GetComponent<Transform>());
    }

    /// <summary>
    /// Обнуляем состояние ИИ
    /// </summary>
    public void ReInitEnemy()
    {
        InitArrayCells();
        enable = true;
    }
    /// <summary>
    /// Метод "Ход противника", в котором: генерируем случайный индекс; определяем есть ли спрайт в элементе массива с данным индексом;
    /// если спрайт отсутствует, отрисовываем "нолик", проигрываем звук и удаляем элемент из массива; в противном случае (спрайт инициализирован крестиком),
    /// удаляем элемент из массива и повторяем метод заново.
    /// </summary>
    void TurnEnemy()
    {
        while (enable && Turn.turn)
        { //Цикл работает пока не будет передан ход или не отключен ИИ
            int randomIndex = (int)Random.Range(0.0f, freeCells.Count - 1);
            if (!freeCells[randomIndex].GetComponent<SpriteRenderer>().sprite)
            {
                freeCells[randomIndex].GetComponent<SpriteRenderer>().sprite = round;
                GetComponent<AudioSource>().Play();
                Transform hitCell = freeCells[randomIndex];

                if (!GameObject.Find("GamePlay").GetComponent<GamePlayController>().CheckWin(hitCell, namePlayer))
                {
                    Turn.turn = false;
                    StartCoroutine(Turn.SetPouse());
                }
                else // Если победа, отключаем ИИ
                    enable = false;
            }

            freeCells.RemoveAt(randomIndex);

            // Отключаем ИИ если все ячейки зарисованы и при этом нет победителя т.е. ничья (иначе происходит ошибка выхода за пределы массива)
            if (freeCells.Count < 1)
            {
                enable = false;
                // Посылаем null'ы давая знать, что ничья
                GameObject.Find("GamePlay").GetComponent<GamePlayController>().CheckWin(null, null);
            }
        }
    }
}
