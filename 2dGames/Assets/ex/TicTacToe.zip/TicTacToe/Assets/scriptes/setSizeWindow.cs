﻿using UnityEngine;

public class setSizeWindow : MonoBehaviour
{

	public int width = 314;
	public int height = 401;

	// Use this for initialization
	void Awake ()
	{
		Screen.SetResolution(width, height, false);
	}
}
