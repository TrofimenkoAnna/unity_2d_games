﻿using UnityEngine;

public class CellClass : MonoBehaviour
{
    public int posCell, posColl;
}
