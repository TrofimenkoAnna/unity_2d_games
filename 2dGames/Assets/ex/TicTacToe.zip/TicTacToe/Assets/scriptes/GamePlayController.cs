﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class GamePlayController : MonoBehaviour
{
    public Image win, fail, standoff;       //Сообщения о победе, проигрыше, или ничьей
    public Transform line;
    public Transform cell;                  //Префаб-триггер
    public Transform cellsParent;           //Объект-папка для ячеек
    private Transform[,] sprites;          //Массив ячеек поля
    private float x = -0.85f;
    private float y = 0.75f;

    // Use this for initialization
    void Awake ()
    {
        InitField();
    }

    /// <summary>
    /// Инициализируем поле префабами-триггерами, для отловки кликов по ячейкам.
    /// А так же массив ячеек.
    /// </summary>
    void InitField()
    {
        int arrColl = 0, arrCell = 0;
        sprites = new Transform[3, 3];
        for (int i = 1; i <= 9; i++)
        {
            Transform tempObj = (Transform)Instantiate(cell, new Vector3(x, y, 0), Quaternion.identity);
            sprites[arrColl, arrCell] = tempObj;
            tempObj.transform.SetParent(cellsParent.transform);
            tempObj.GetComponent<CellClass>().posCell = arrCell;
            tempObj.GetComponent<CellClass>().posColl = arrColl;
            
            arrColl++;
            x += 0.85f;

            //Смещаемся на строку вниз, сбрасываем колонку
            if (i % 3 == 0)
            {
                arrColl = 0;
                arrCell++;
                x = -0.85f;
                y -= 0.85f;
            }
        }
    }
    /// <summary>
    /// Метод проверяющий, есть ли условия победы после последнего хода.
    /// </summary>
    /// <param name="callerCell"></param> - последний сделанный ход (ячейка)
    /// <param name="callerFigure"></param> - кем сделан ход (крестик/нолик)
    /// <returns>bool isWin</returns>
    public bool CheckWin(Transform callerCell, string callerFigure)
    {
        bool isWin = false;
        if (callerCell)
        {   //Если в параметрах не null, чекаем на победу....
            Vector2 currenPos = new Vector2();
            currenPos.x = callerCell.GetComponent<CellClass>().posColl;
            currenPos.y = callerCell.GetComponent<CellClass>().posCell;

            if (StepByField(new Vector2(0, -1), currenPos) == 2) //Вверх-вниз             x - колонка / у - строка
            {
                DrawLine(sprites[(int) currenPos.x, (int) currenPos.y].position, "vertical");
                StartCoroutine(ShowMessage(callerFigure));
                isWin = true;
            }
            else if (StepByField(new Vector2(1, -1), currenPos) == 2) //Вверх-вправо
            {
                DrawLine(sprites[(int) currenPos.x, (int) currenPos.y].position, "left_diagonal");
                StartCoroutine(ShowMessage(callerFigure));
                isWin = true;
            }
            else if (StepByField(new Vector2(1, 0), currenPos) == 2) //Вправо-влево
            {
                DrawLine(sprites[(int) currenPos.x, (int) currenPos.y].position, "horizontal");
                StartCoroutine(ShowMessage(callerFigure));
                isWin = true;
            }
            else if (StepByField(new Vector2(1, 1), currenPos) == 2) //Вниз-вправо
            {
                DrawLine(sprites[(int) currenPos.x, (int) currenPos.y].position, "right_diagonal");
                StartCoroutine(ShowMessage(callerFigure));
                isWin = true;
            }
        }
        else // .... в противном случае, передаем null дальше, для вывода сообщение о ничьей
            StartCoroutine(ShowMessage(null));

        return isWin;
    }

    /// <summary>
    /// Метод "шагания" по массиву, от текущей позиции Vector2 currentPosition, в заданном направлении Vector2 vector.
    /// Шагание продолжается пока "курсор" Vector2 step не выйдет за пределы массива, или спрайт под "курсором" 
    /// не будет соответствовать спрайту начальной позиции. После чего, вектор реверсируется и процедура повторяется.
    /// Метод возвращает количество найденых совпадающих спрайтов с начальным.
    /// </summary>
    /// <param name="vector"></param> - направление движения по массиву
    /// <param name="currentPosition"></param> - текущая позиция в массиве, откуда двигаемся
    /// <returns>int coincide</returns> - количество совпадений
    int StepByField(Vector2 vector, Vector2 currentPosition)
    {   //TODO -- реализовать свой вариант Vector2 интовый. Не критично.
        int coincide = 0;
        
        Vector2 step = currentPosition + vector;
        string figure = sprites[(int)currentPosition.x, (int)currentPosition.y].GetComponent<SpriteRenderer>().sprite.name;

        int stop = 0;
        while (stop < 2)
        {
                                                                                                                   //  Блок проверок:
            if ((step.x > -1 && step.y > -1 && step.x < 3 && step.y < 3)                                           // -Проверка выхода за пределы массива
                && (sprites[(int) step.x, (int) step.y].GetComponent<SpriteRenderer>().sprite)                     // -Проверка на наличии спрайта в "ячейке"
                && sprites[(int)step.x, (int)step.y].GetComponent<SpriteRenderer>().sprite.name == figure)         // -Проверка соответствует ли следующий
                                                                                                                   // спрайт, "ходящему"
            {
                coincide++;
                step += vector;
            }
            else
            {
                vector *= -1;
                step = currentPosition + vector;
                stop++;
            }
        }
        return coincide;
    }

    IEnumerator ShowMessage(string winner)
    {
        yield return new WaitForSeconds(1.0f);

        GameObject.Find("field_spr").GetComponent<SpriteRenderer>().enabled = false;
        Destroy(GameObject.Find("line(Clone)"));
        foreach (Transform sprite in sprites)
            sprite.GetComponent<SpriteRenderer>().sprite = null;

        if (winner != null)
        {   //Есть победитель
            if (GameObject.Find("Player").GetComponent<Player>().namePlayer == winner)
            {
                win.enabled = true;
                win.GetComponent<AudioSource>().Play();
            }
            else
            {
                fail.enabled = true;
                fail.GetComponent<AudioSource>().Play();
            }
        }
        else
        {   //Ничья
            standoff.enabled = true;
            standoff.GetComponent<AudioSource>().Play();
        }
    }

    /// <summary>
    /// Метод отрисовки линии перечеркивания ряда
    /// </summary>
    /// <param name="position"></param> - координаты спрайта завершившего ряд
    /// <param name="orientation"></param> - ориентация линии (горизонталь, вертикаль, правая или левая диагональ)
    void DrawLine(Vector2 position, string orientation)
    {
        Vector3 posLine = position;
        Transform tr;
        switch (orientation)
        {
            case "vertical":
                posLine.y = 0; // Центрируем линию по вертикали
                Instantiate(line, posLine, Quaternion.identity);
                break;
            case "horizontal":
                posLine.x = 0; // Центрируем линию по горизонтали
                Instantiate(line, posLine, Quaternion.Euler(0, 0, 90));
                break;
            case "left_diagonal":
                // Диагональ всегда проходит через центр, поэтому инстанцируем ее в нулевых координатах
                // После инстанцирования, не много растягиваем линию
                tr = (Transform)Instantiate(line, new Vector3(0, 0, 0), Quaternion.Euler(0,0,-45));
                tr.localScale += new Vector3(0, 0.3f, 0);
                break;
            case "right_diagonal":
                tr = (Transform)Instantiate(line, new Vector3(0, 0, 0), Quaternion.Euler(0, 0, 45));
                tr.localScale += new Vector3(0, 0.3f, 0);
                break;
        }
    }

    /// <summary>
    /// Обнуляем состояние игры
    /// </summary>
    public void Restart()
    {
        Turn.turn = false;
        GameObject.Find("field_spr").GetComponent<SpriteRenderer>().enabled = true;
        GameObject.Find("Enemy").GetComponent<Enemy>().ReInitEnemy();
        GameObject.Find("Player").GetComponent<Player>().ReinitPlayer();

        if (!win.enabled && !fail.enabled && !standoff.enabled)
        {
            foreach (Transform sprite in sprites)
                sprite.GetComponent<SpriteRenderer>().sprite = null;
        }

        win.enabled = false;
        fail.enabled = false;
        standoff.enabled = false;
    }
}
