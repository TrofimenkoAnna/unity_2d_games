﻿using UnityEngine;

public class Player : MonoBehaviour
{
    public string namePlayer = "Cross";
    public Sprite cross;
    private bool enable = true;

    void Update()
    {
        if (enable && Input.GetMouseButtonDown(0))
            ClickPlayer();
    }

    void ClickPlayer()
    {
        Vector2 clickPoint = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        RaycastHit2D hit = Physics2D.Raycast(clickPoint, Vector2.zero);

        if (hit.collider)
        {
            Transform hitCell = hit.transform;

            if (!hitCell.GetComponent<SpriteRenderer>().sprite && !Turn.turn && !Turn.Pause)
            {
                hitCell.GetComponent<SpriteRenderer>().sprite = cross;
                GetComponent<AudioSource>().Play();

                if (!GameObject.Find("GamePlay").GetComponent<GamePlayController>().CheckWin(hitCell, namePlayer))
                {
                    Turn.turn = true;
                    StartCoroutine(Turn.SetPouse());
                }
                else // Если победа, отключаем плеер
                    enable = false;
            }
        }
    }
    public void ReinitPlayer()
    {
        enable = true;
    }
}
